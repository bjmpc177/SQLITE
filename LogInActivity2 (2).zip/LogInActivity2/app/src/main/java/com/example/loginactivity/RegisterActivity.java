package com.example.loginactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {
    DatabaseHelper db;
    EditText mTextUsername;
    EditText  mTextPassword;
    EditText getmTextCnfPassword;
    EditText getmTextFullname;
    Button mButtonRegister;
    TextView mTextviewLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        mTextUsername = (EditText)findViewById(R.id.username);
        mTextPassword = (EditText)findViewById(R.id.password);
        getmTextCnfPassword = (EditText)findViewById(R.id.cnf_password);
        getmTextFullname = (EditText)findViewById(R.id.fname);
        mButtonRegister= (Button) findViewById(R.id.btn_register);
        mTextviewLogin = (TextView) findViewById(R.id.textview_log_in);
        mButtonRegister.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(RegisterActivity.this,LoginActivity.class);
            startActivity(intent);
        }
    });
       mButtonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = mTextUsername.getText().toString().trim();
                String password = mTextPassword.getText().toString().trim();
                String cnf_pssd = getmTextCnfPassword.getText().toString().trim();

                if (password.equals(cnf_pssd)){
                    long val = db.addUser(user,password);
                    if (val > 0){
                        Intent intent = new Intent(RegisterActivity.this,LoginActivity.class);
                        Toast.makeText(RegisterActivity.this,"You have Registered", Toast.LENGTH_SHORT).show();
                        startActivity(intent);
                    }
                    else {
                        Toast.makeText(RegisterActivity.this,"Registration error!!!", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });
    }
}
